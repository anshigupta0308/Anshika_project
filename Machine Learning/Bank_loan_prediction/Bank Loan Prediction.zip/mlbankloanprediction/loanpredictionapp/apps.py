from django.apps import AppConfig


class LoanpredictionappConfig(AppConfig):
    name = 'loanpredictionapp'
